USE [BI_WAREHOUSE_900_META_DATA]
GO

/****** Object:  Table [dbo].[ETL_CONTROL]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_CONTROL](
	[control_id] [int] IDENTITY(1,1) NOT NULL,
	[project_code] [varchar](20) NOT NULL,
	[phase_code] [varchar](20) NOT NULL,
	[job_name] [varchar](200) NOT NULL,
	[job_type_code] [varchar](20) NOT NULL,
	[extract_type_code] [varchar](20) NULL,
	[extract_offset_days] [int] NULL,
	[master_job_indicator] [char](1) NOT NULL,
	[last_extract_date] [datetime2](3) NULL,
	[current_extract_date] [datetime2](3) NULL,
	[load_id] [int] NOT NULL,
	[status_code] [varchar](2) NOT NULL,
	[inactive_indicator] [char](1) NOT NULL,
	[target_table_name] [varchar](100) NULL,
	[business_key] [varchar](200) NULL,
	[extract_offset_minutes] [int] NULL,
 CONSTRAINT [PK_ETL_CONTROL] PRIMARY KEY CLUSTERED 
(
	[control_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY],
 CONSTRAINT [AK_ETL_CONTROL] UNIQUE NONCLUSTERED 
(
	[project_code] ASC,
	[job_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_ERROR]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_ERROR](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[project_code] [varchar](20) NOT NULL,
	[job_name] [varchar](200) NOT NULL,
	[category] [varchar](200) NOT NULL,
	[error_datetime] [datetime2](7) NOT NULL,
	[error_record] [varchar](max) NOT NULL,
	[dw_load_id] [int] NOT NULL,
 CONSTRAINT [PK_ETL_ERROR] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY]
) ON [SECONDARY] TEXTIMAGE_ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_ERROR_DUPLICATE]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_ERROR_DUPLICATE](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[project_code] [varchar](20) NOT NULL,
	[job_name] [varchar](200) NOT NULL,
	[cutoff_date_indicator] [char](1) NOT NULL,
	[cutoff_date_sql] [varchar](8000) NULL,
	[sort_sql] [varchar](500) NOT NULL,
	[inactive_indicator] [char](1) NOT NULL,
	[error_retention_days] [int] NULL,
 CONSTRAINT [PK_ETL_ERROR_DUPLICATE] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_JOB_TYPE]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_JOB_TYPE](
	[job_type_code] [varchar](20) NOT NULL,
	[job_type_description] [varchar](200) NOT NULL,
 CONSTRAINT [PK_ETL_JOB_TYPE] PRIMARY KEY CLUSTERED 
(
	[job_type_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_LOAD]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_LOAD](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[project_code] [varchar](20) NOT NULL,
	[parent_job_name] [varchar](200) NULL,
	[job_name] [varchar](200) NOT NULL,
	[last_extract_date] [datetime2](3) NULL,
	[current_extract_date] [datetime2](3) NULL,
	[rows_source] [int] NULL,
	[rows_insert] [int] NULL,
	[rows_update] [int] NULL,
	[rows_delete] [int] NULL,
	[rows_discard] [int] NULL,
	[rows_reject] [int] NULL,
	[load_id] [int] NULL,
	[status_code] [varchar](2) NOT NULL,
	[job_start_date] [datetime2](3) NULL,
	[job_end_date] [datetime2](3) NULL,
	[load_minutes] [decimal](10, 2) NULL,
	[job_execution_system_id] [varchar](100) NULL,
	[version_id] [int] NOT NULL,
 CONSTRAINT [PK_ETL_LOAD] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_PARAMETER]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_PARAMETER](
	[parameter_id] [int] IDENTITY(1,1) NOT NULL,
	[project_code] [varchar](20) NULL,
	[parameter_group] [varchar](100) NULL,
	[parameter_key_code] [varchar](100) NOT NULL,
	[parameter_value_code] [varchar](1000) NULL,
	[parameter_description] [varchar](1000) NOT NULL,
 CONSTRAINT [PK_ETL_PARAMETER] PRIMARY KEY CLUSTERED 
(
	[parameter_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_PHASE]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_PHASE](
	[phase_code] [varchar](20) NOT NULL,
	[phase_description] [varchar](1000) NOT NULL,
 CONSTRAINT [PK_ETL_PHASE] PRIMARY KEY CLUSTERED 
(
	[phase_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_PROJECT]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_PROJECT](
	[project_code] [varchar](20) NOT NULL,
	[project_description] [varchar](1000) NOT NULL,
 CONSTRAINT [PK_ETL_PROJECT] PRIMARY KEY CLUSTERED 
(
	[project_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_SOURCE]    Script Date: 12/06/2025 11:01:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_SOURCE](
	[source_id] [int] IDENTITY(1,1) NOT NULL,
	[source_code] [varchar](20) NOT NULL,
	[source_name] [varchar](100) NOT NULL,
	[source_description] [varchar](4000) NOT NULL,
	[inactive_indicator] [char](1) NOT NULL,
 CONSTRAINT [PK_ETL_SOURCE] PRIMARY KEY CLUSTERED 
(
	[source_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY],
 CONSTRAINT [AK_ETL_SOURCE] UNIQUE NONCLUSTERED 
(
	[source_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY],
 CONSTRAINT [UIX_ETL_SOURCE_NAME] UNIQUE NONCLUSTERED 
(
	[source_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[ETL_STATUS]    Script Date: 12/06/2025 11:01:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ETL_STATUS](
	[status_code] [varchar](2) NOT NULL,
	[status_description] [varchar](1000) NOT NULL,
 CONSTRAINT [PK_ETL_STATUS] PRIMARY KEY CLUSTERED 
(
	[status_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[INT_ENTITY]    Script Date: 12/06/2025 11:01:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INT_ENTITY](
	[entity_id] [int] IDENTITY(1,1) NOT NULL,
	[entity_type_code] [varchar](50) NOT NULL,
	[entity_name] [varchar](200) NOT NULL,
	[semantic_name] [varchar](200) NOT NULL,
	[owner_name] [varchar](200) NOT NULL,
	[security_classification_code] [varchar](200) NULL,
	[inactive_indicator] [char](1) NOT NULL,
	[effective_from_date] [datetime2](3) NOT NULL,
	[effective_to_date] [datetime2](3) NULL,
	[current_record_indicator] [char](1) NOT NULL,
 CONSTRAINT [PK_INT_ENTITY] PRIMARY KEY CLUSTERED 
(
	[entity_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY],
 CONSTRAINT [AK_INT_ENTITY] UNIQUE NONCLUSTERED 
(
	[entity_name] ASC,
	[effective_from_date] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[INT_ENTITY_EXECUTION_LOG]    Script Date: 12/06/2025 11:01:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INT_ENTITY_EXECUTION_LOG](
	[entity_execution_log_id] [int] IDENTITY(1,1) NOT NULL,
	[dw_load_id] [int] NOT NULL,
	[entity_type_code] [varchar](50) NOT NULL,
	[entity_name] [varchar](200) NOT NULL,
	[interface_name] [varchar](200) NOT NULL,
	[format_code] [varchar](50) NOT NULL,
	[extract_location] [varchar](800) NULL,
	[file_name] [varchar](100) NULL,
	[rows_inserted] [int] NULL,
	[execution_datetime] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_INT_ENTITY_EXECUTION_LOG] PRIMARY KEY CLUSTERED 
(
	[entity_execution_log_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[INT_INTERFACE]    Script Date: 12/06/2025 11:01:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INT_INTERFACE](
	[interface_id] [int] IDENTITY(1,1) NOT NULL,
	[interface_type] [varchar](20) NOT NULL,
	[interface_code] [varchar](20) NOT NULL,
	[interface_name] [varchar](200) NOT NULL,
	[direction_indicator] [varchar](20) NOT NULL,
	[business_unit_name] [varchar](200) NULL,
	[owner_name] [varchar](50) NOT NULL,
	[folder_location] [varchar](200) NULL,
	[description] [varchar](8000) NULL,
	[security_classification_code] [varchar](200) NULL,
	[security_group] [varchar](200) NULL,
	[inactive_indicator] [char](1) NOT NULL,
	[effective_from_date] [datetime2](3) NOT NULL,
	[effective_to_date] [datetime2](3) NULL,
	[current_record_indicator] [char](1) NOT NULL,
 CONSTRAINT [PK_INT_INTERFACE] PRIMARY KEY CLUSTERED 
(
	[interface_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY],
 CONSTRAINT [AK_INT_INTERFACE] UNIQUE NONCLUSTERED 
(
	[interface_code] ASC,
	[effective_from_date] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[INT_INTERFACE_AGREEMENT]    Script Date: 12/06/2025 11:01:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INT_INTERFACE_AGREEMENT](
	[interface_agreement_id] [int] IDENTITY(1,1) NOT NULL,
	[interface_id] [int] NOT NULL,
	[business_unit_name] [varchar](200) NULL,
	[owner_name] [varchar](50) NOT NULL,
	[format_code] [varchar](50) NULL,
	[interval_code] [varchar](50) NULL,
	[interval_sunday] [char](1) NULL,
	[interval_monday] [char](1) NULL,
	[interval_tuesday] [char](1) NULL,
	[interval_wednesday] [char](1) NULL,
	[interval_thursday] [char](1) NULL,
	[interval_friday] [char](1) NULL,
	[interval_saturday] [char](1) NULL,
	[inactive_indicator] [char](1) NOT NULL,
	[effective_from_date] [datetime2](3) NOT NULL,
	[effective_to_date] [datetime2](3) NULL,
	[current_record_indicator] [char](1) NOT NULL,
 CONSTRAINT [PK_INT_INTERFACE_AGREEMENT] PRIMARY KEY CLUSTERED 
(
	[interface_agreement_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[INT_INTERFACE_ENTITY]    Script Date: 12/06/2025 11:01:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INT_INTERFACE_ENTITY](
	[interface_entity_id] [int] IDENTITY(1,1) NOT NULL,
	[interface_id] [int] NOT NULL,
	[entity_id] [int] NOT NULL,
 CONSTRAINT [PK_INT_INTERFACE_ENTITY] PRIMARY KEY CLUSTERED 
(
	[interface_entity_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY],
 CONSTRAINT [AK_INT_INTERFACE_ENTITY] UNIQUE NONCLUSTERED 
(
	[interface_id] ASC,
	[entity_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [SECONDARY]
) ON [SECONDARY]
GO

/****** Object:  Table [dbo].[VERSION]    Script Date: 12/06/2025 11:01:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[VERSION](
	[version_id] [int] IDENTITY(1,1) NOT NULL,
	[version] [varchar](100) NOT NULL,
	[build] [varchar](100) NOT NULL,
	[build_date] [datetime] NOT NULL,
	[deploy_date] [datetime] NOT NULL,
	[database_server] [varchar](50) NOT NULL,
 CONSTRAINT [PK_VERSION] PRIMARY KEY CLUSTERED 
(
	[version] ASC,
	[build] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, DATA_COMPRESSION = PAGE) ON [SECONDARY]
) ON [SECONDARY]
GO

ALTER TABLE [dbo].[ETL_CONTROL]  WITH CHECK ADD  CONSTRAINT [FK_ETL_CONTROL_JOB_TYPE_CODE] FOREIGN KEY([job_type_code])
REFERENCES [dbo].[ETL_JOB_TYPE] ([job_type_code])
GO

ALTER TABLE [dbo].[ETL_CONTROL] CHECK CONSTRAINT [FK_ETL_CONTROL_JOB_TYPE_CODE]
GO

ALTER TABLE [dbo].[ETL_CONTROL]  WITH CHECK ADD  CONSTRAINT [FK_ETL_CONTROL_PHASE_CODE] FOREIGN KEY([phase_code])
REFERENCES [dbo].[ETL_PHASE] ([phase_code])
GO

ALTER TABLE [dbo].[ETL_CONTROL] CHECK CONSTRAINT [FK_ETL_CONTROL_PHASE_CODE]
GO

ALTER TABLE [dbo].[ETL_CONTROL]  WITH CHECK ADD  CONSTRAINT [FK_ETL_CONTROL_PROJECT_CODE] FOREIGN KEY([project_code])
REFERENCES [dbo].[ETL_PROJECT] ([project_code])
GO

ALTER TABLE [dbo].[ETL_CONTROL] CHECK CONSTRAINT [FK_ETL_CONTROL_PROJECT_CODE]
GO

ALTER TABLE [dbo].[ETL_CONTROL]  WITH CHECK ADD  CONSTRAINT [FK_ETL_CONTROL_STATUS_CODE] FOREIGN KEY([status_code])
REFERENCES [dbo].[ETL_STATUS] ([status_code])
GO

ALTER TABLE [dbo].[ETL_CONTROL] CHECK CONSTRAINT [FK_ETL_CONTROL_STATUS_CODE]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for a control record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'control_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Project that this job belongs to.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'project_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Phase that the job belongs to.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'phase_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the job. For an SSIS Package, this is the name of the package.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'job_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Type of job.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'job_type_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicator (Y/N) that defines whether this job is the Master. The first job that runs and controls others. This is the job that will set the EXECUTING_FLAG parameter to say that the job is currently executing.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'master_job_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'For delta processing this is the last date that data was extracted from the source.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'last_extract_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'For delta processing this is the current date that data is to be extracted to from the source.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'current_extract_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Incrementing number that allocates a new number to each load cycle for a job. All data loaded as part of this load is tagged with this ID to provide lineage and auditability of data loads.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'load_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The status of the job. Refer to ETL_STATUS for possible values.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'status_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicator that allows for disabling of jobs.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'inactive_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Target table that this job loads. Is used to help with rebuilding warehouse and truncating tables.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL', @level2type=N'COLUMN',@level2name=N'target_table_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Main table for controlling the processes (Packages) that run as part of an ETL cycle. Every package that executes must have a record in this table.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_CONTROL'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for a record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR', @level2type=N'COLUMN',@level2name=N'id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Project that this job belongs to.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR', @level2type=N'COLUMN',@level2name=N'project_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the job. For an SSIS Package, this is the name of the package.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR', @level2type=N'COLUMN',@level2name=N'job_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Category of error. Used as a way to group errors together' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR', @level2type=N'COLUMN',@level2name=N'category'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Date and time the error occurred.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR', @level2type=N'COLUMN',@level2name=N'error_datetime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Contents of record that had the error.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR', @level2type=N'COLUMN',@level2name=N'error_record'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ETL load ID that error occurred in.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR', @level2type=N'COLUMN',@level2name=N'dw_load_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Table to store errors encountered during ETL processing' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for a record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE', @level2type=N'COLUMN',@level2name=N'id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Project that this job belongs to.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE', @level2type=N'COLUMN',@level2name=N'project_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the job. For an SSIS Package, this is the name of the package.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE', @level2type=N'COLUMN',@level2name=N'job_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicator for whether to apply a high watermark cut-off to the data. Restricts records to within delta period.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE', @level2type=N'COLUMN',@level2name=N'cutoff_date_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'SQL use when high watermark cut-off data is required.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE', @level2type=N'COLUMN',@level2name=N'cutoff_date_sql'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'SQL snippet for sorting data.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE', @level2type=N'COLUMN',@level2name=N'sort_sql'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicator that allows for disabling of de-duplication processes.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE', @level2type=N'COLUMN',@level2name=N'inactive_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Meta data for de-duplicating data in the Staging database' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_ERROR_DUPLICATE'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique code for a job type' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_JOB_TYPE', @level2type=N'COLUMN',@level2name=N'job_type_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Description for this job type' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_JOB_TYPE', @level2type=N'COLUMN',@level2name=N'job_type_description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'A type of job that can execute within the ETL framework and data warehouse.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_JOB_TYPE'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for a record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Project that this job belongs to.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'project_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the parent of this job.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'parent_job_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the job. For an SSIS Package, this is the name of the package.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'job_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'For delta processing this is the last date that data was extracted from the source.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'last_extract_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'For delta processing this is the current date that data is to be extracted to from the source.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'current_extract_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of rows read from source.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'rows_source'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of rows inserted into target.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'rows_insert'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of rows updated in target.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'rows_update'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of rows deleted from target.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'rows_delete'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of rows discarded from input.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'rows_discard'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of rows rejected due to issues.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'rows_reject'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Load if from the ETL_CONTROL table for this job. All data loaded as part of this load is tagged with this ID to provide lineage and auditability of data loads.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'load_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The status of the job. Refer to ETL_STATUS for possible values.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'status_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Start datetime of job execution' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'job_start_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'End datetime of job execution.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'job_end_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Duration in minutes of job execution.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'load_minutes'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'SSIS execution GUID for this job load.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'job_execution_system_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The database version in operation at the time of this load.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD', @level2type=N'COLUMN',@level2name=N'version_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Logs results of processes (Packages) that run as part of an ETL cycle.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_LOAD'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier that identifies this Parameter' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PARAMETER', @level2type=N'COLUMN',@level2name=N'parameter_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Project specific parameter' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PARAMETER', @level2type=N'COLUMN',@level2name=N'project_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Group name for a collection of Parameters. Allows you to group parameters together' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PARAMETER', @level2type=N'COLUMN',@level2name=N'parameter_group'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Parameter code' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PARAMETER', @level2type=N'COLUMN',@level2name=N'parameter_key_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Parameter value' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PARAMETER', @level2type=N'COLUMN',@level2name=N'parameter_value_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Description for this Parameter' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PARAMETER', @level2type=N'COLUMN',@level2name=N'parameter_description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Parameters that can be used across the ETL Solution' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PARAMETER'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique code for a phase' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PHASE', @level2type=N'COLUMN',@level2name=N'phase_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Description for this phase' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PHASE', @level2type=N'COLUMN',@level2name=N'phase_description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Phase within the ETL framework and data warehouse.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PHASE'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique code for a project' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PROJECT', @level2type=N'COLUMN',@level2name=N'project_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Description for a project' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PROJECT', @level2type=N'COLUMN',@level2name=N'project_description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Projects that utilise the ETL framework.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_PROJECT'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for the ETL Source System' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_SOURCE', @level2type=N'COLUMN',@level2name=N'source_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'AK unique code that identifies this ETL Source System' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_SOURCE', @level2type=N'COLUMN',@level2name=N'source_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'UIX unique name that identifies this ETL Source System' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_SOURCE', @level2type=N'COLUMN',@level2name=N'source_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Description for this ETL Source System' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_SOURCE', @level2type=N'COLUMN',@level2name=N'source_description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'This indicator can be used to deactivate ETL feeds from this specific source, for example if a particular source system is temporarily unavailable (planned) it can be deactivated by setting this flag to "Y" so that standard ETL processing can still succeed for all other sources.
	This indicator should be referenced by any SSIS package(s) that reference this source to determine if processing should occur.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_SOURCE', @level2type=N'COLUMN',@level2name=N'inactive_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'A source system from which data is extracted and loaded into the Data Warehouse via ETL.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_SOURCE'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique code for a status' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_STATUS', @level2type=N'COLUMN',@level2name=N'status_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Description for this status' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_STATUS', @level2type=N'COLUMN',@level2name=N'status_description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Status within the ETL framework and data warehouse.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ETL_STATUS'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for an entity record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'entity_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The type of entity. Example: View, File, Stored Procedure' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'entity_type_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the entity. This can be a file name, view name etc.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'entity_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The semantic name of the entity. This can be used to form the name of a file if required' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'semantic_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Person that is responsible from the business for the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'owner_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The security classification of the data contained in the interface. Example: Confidential, Restricted. [Note: need to define these].' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'security_classification_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicator that allows for disabling of records.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'inactive_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Start date of when entity is applicable.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'effective_from_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'End date of when entity is applicable.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'effective_to_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates whether the entity is the latest version.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY', @level2type=N'COLUMN',@level2name=N'current_record_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for an interface record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'entity_execution_log_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The ETL load ID that file was generted in' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'dw_load_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The type of entity. Example: View, File, Stored Procedure' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'entity_type_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the entity.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'entity_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the interface' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'interface_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Format of file extracted' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'format_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The folder location where the file was extracted to.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'extract_location'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the file produced' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'file_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The number of rows inserted into the file' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'rows_inserted'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The date and time of file extract' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_ENTITY_EXECUTION_LOG', @level2type=N'COLUMN',@level2name=N'execution_datetime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for an interface record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'interface_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The type of interface. Example: Business Unit specific or generic data extract' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'interface_type'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'A unique code for the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'interface_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The name of the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'interface_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates whether the interface is "Inbound" or "Outbound".' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'direction_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The business unit that owns the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'business_unit_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Person that is responsible from the business for the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'owner_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Folder location for file drops.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'folder_location'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'A description in business terms of the purpose of the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'description'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The security classification of the data contained in the interface. Example: Confidential, Restricted. [Note: need to define these].' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'security_classification_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The security group that provides access to the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'security_group'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicator that allows for disabling of jobs.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'inactive_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Start date of when interface is applicable.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'effective_from_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'End date of when interface is applicable.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'effective_to_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates whether the interface is the latest version.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE', @level2type=N'COLUMN',@level2name=N'current_record_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for an interface record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interface_agreement_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'FK to an interface record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interface_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The business unit that owns the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'business_unit_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Person that is responsible from the business for the interface.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'owner_name'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Format of interface output required.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'format_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Frequency of interface extract.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates if extract is required on this day.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_sunday'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates if extract is required on this day.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_monday'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates if extract is required on this day.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_tuesday'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates if extract is required on this day.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_wednesday'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates if extract is required on this day.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_thursday'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates if extract is required on this day.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_friday'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates if extract is required on this day.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'interval_saturday'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicator that allows for disabling of jobs.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'inactive_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Start date of when interface is applicable.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'effective_from_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'End date of when interface is applicable.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'effective_to_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Indicates whether the interface agreement is the latest version.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_AGREEMENT', @level2type=N'COLUMN',@level2name=N'current_record_indicator'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'PK unique identifier for an interface entity record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_ENTITY', @level2type=N'COLUMN',@level2name=N'interface_entity_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'FK to a interface record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_ENTITY', @level2type=N'COLUMN',@level2name=N'interface_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'FK to an entity record.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INT_INTERFACE_ENTITY', @level2type=N'COLUMN',@level2name=N'entity_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'unique identifier for a record' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VERSION', @level2type=N'COLUMN',@level2name=N'version_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The version number of the release.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VERSION', @level2type=N'COLUMN',@level2name=N'version'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The build number of the depoyment package' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VERSION', @level2type=N'COLUMN',@level2name=N'build'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The build date of the depoyment package' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VERSION', @level2type=N'COLUMN',@level2name=N'build_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The deployment date of the build' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VERSION', @level2type=N'COLUMN',@level2name=N'deploy_date'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The server of deployment' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VERSION', @level2type=N'COLUMN',@level2name=N'database_server'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Version information for database. Tracks version numbers and deployment dates.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'VERSION'
GO


